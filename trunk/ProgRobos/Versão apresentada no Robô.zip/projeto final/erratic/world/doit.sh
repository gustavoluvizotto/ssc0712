#!/bin/bash

player pursuit.cfg

