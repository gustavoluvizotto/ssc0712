#ifndef PARAMETERS_H
#define PARAMETERS_H

#define THETA_MIN 85     // minimo angulo do laser
#define THETA_MAX 595   // 180, definido no sick.inc
#define LENGTH 3.0      // the max length of a data = 3m
#define THETA_MID (THETA_MAX+THETA_MIN)/2

#endif	//PARAMETERS_H
