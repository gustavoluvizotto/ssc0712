/* 
 * File:   CircleAndLegDetection.cpp
 * Author: gustavo
 * 
 * Created on June 12, 2013, 8:42 AM
 */

#include "CircleAndLegDetection.h"

CircleAndLegDetection::CircleAndLegDetection() {
}

CircleAndLegDetection::CircleAndLegDetection(const CircleAndLegDetection& orig) {
}

CircleAndLegDetection::~CircleAndLegDetection() {
}

void CircleAndLegDetection::setCenter(Point<double> C1) {
    
}