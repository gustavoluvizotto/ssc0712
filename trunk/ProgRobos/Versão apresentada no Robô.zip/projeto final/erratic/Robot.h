#ifndef ROBOT_H
#define	ROBOT_H

#include "Parameters.h"
#include "StateMachine.h"
#include "RobotStates.h"
#include "MotionDetection.h"
#include "Point.h"
#include <libplayerc/playerc.h>

class Robot {
private:
    StateMachine<Robot>* m_pStateMachine;
    
    playerc_client_t* client;
    playerc_position2d_t* position2d;
    playerc_laser_t* laser;
    playerc_ranger_t* ranger;

    //PlayerClient* client;
    //Position2dProxy* m_pPp;
    //RangerProxy* m_pRp;
    
    MotionDetection* m_pMD; //ponteiro pra classe MotionDetection
    
    void SetSpeed(const double XSpeed, const double YawSpeed) const {
        playerc_position2d_set_cmd_vel(position2d, XSpeed, 0, YawSpeed, 1);
    }
    
public:

    Robot() {
        m_pStateMachine = new StateMachine<Robot>(this);
        m_pStateMachine->SetGlobalState(SGlobalExample::Instance());
        m_pStateMachine->SetCurrentState(S_Andando::Instance());
        client = playerc_client_create(NULL, "localhost", 6665);
        if (playerc_client_connect(client) == 0) {
            cout << "PLAYERC_CLIENT_CONNECT() ERROR!" << endl;
            exit(-1);
		}
		
        position2d = playerc_position2d_create(client, 0);
        if (playerc_position2d_subscribe(position2d, PLAYERC_OPEN_MODE) != 0) {
        	cout << "PLAYERC_POSITION2D_SUBSCRIBE() ERROR!" << endl;
            exit(-1);
        }

        playerc_position2d_enable(position2d, 1);

        for (int i = 0; i < 10000; i++)
            cout << "Warming up ranger..." << endl;
        laser = playerc_laser_create(client, 0);
        if (playerc_laser_subscribe(laser, PLAYERC_OPEN_MODE)) {
            cout << "PLAYERC_LASER_SUBSCRIBE() ERROR!" << endl;
            exit(-1);
		}
		
        for (int i = 0; i < 10000; i++)
            cout << "Warming up laser..." << endl;

        for (int i = 0; i < 10; i++)
            playerc_client_read(client);

        m_pMD = new MotionDetection(this);
    }

    virtual ~Robot() {
        if (m_pMD) delete m_pMD;
        if (m_pStateMachine) delete m_pStateMachine;
    }

    void ReadSensors() {
        playerc_client_read(client);
    }

    StateMachine<Robot>* GetFSM() const {
        return m_pStateMachine;
    }

    void Update() {
        ReadSensors();
        m_pStateMachine->Update();
    }

    double GetRange(uint32_t Index) const {
        return laser->scan[Index][0];
    }

    bool willHit() {
        for (int i = THETA_MIN; i < THETA_MAX; i++) {
            if (GetRange(i) <= 0.4) {
                return true;
            }
        }
        return false;
    }

    void walkTurn(double speed, double angle) {
        if (speed > 0.2)
            speed = 0.2;
        if (angle > 3)
            angle = 3;

        SetSpeed(speed, angle);
    }

    MotionDetection* GetMD() {
        return m_pMD;
    }
};

#endif	/* ROBOT_H */
