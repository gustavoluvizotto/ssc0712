#!/bin/bash

g++ -c *.cpp `pkg-config --cflags --libs playerc++`
g++ -o programa *.o `pkg-config --cflags --libs playerc++`

rm *.o
